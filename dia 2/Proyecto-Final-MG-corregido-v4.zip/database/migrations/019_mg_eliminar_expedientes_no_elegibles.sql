-- 019_mg_eliminar_expedientes_no_elegibles.sql
-- Elimina expedientes de estudiantes que no concluyeron la carrera.
-- Las tablas dependientes con ON DELETE CASCADE se limpian automáticamente;
-- las referencias opcionales se ponen en NULL mediante ON DELETE SET NULL.
SET NAMES utf8mb4 COLLATE utf8mb4_unicode_ci;

-- Cancelar solicitudes ordinarias pendientes/confirmadas de egresados o titulados.
UPDATE tutorias t
JOIN estudiantes e ON e.id_estudiante=t.id_estudiante
SET t.estado='cancelada'
WHERE t.estado IN ('pendiente','confirmada')
  AND e.estado_academico IN ('egresado','titulado');

-- Retirar expedientes duplicados activos, conservando el de menor ID por estudiante.
DELETE x FROM expedientes_mg x
JOIN expedientes_mg anterior
  ON anterior.id_estudiante=x.id_estudiante
 AND anterior.estado='activo'
 AND x.estado='activo'
 AND anterior.id_expediente < x.id_expediente;

-- Eliminar por completo expedientes de estudiantes que no cumplen egreso:
-- noveno semestre culminado, estado egresado/titulado y sin inscripciones activas.
DELETE x FROM expedientes_mg x
JOIN estudiantes e ON e.id_estudiante=x.id_estudiante
WHERE e.semestre < 9
   OR e.estado_academico NOT IN ('egresado','titulado')
   OR EXISTS (SELECT 1 FROM inscripciones i WHERE i.id_estudiante=e.id_estudiante AND i.estado='activa');

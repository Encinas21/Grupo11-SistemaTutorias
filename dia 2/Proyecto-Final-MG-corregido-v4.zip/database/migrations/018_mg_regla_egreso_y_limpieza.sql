-- 018_mg_regla_egreso_y_limpieza.sql
-- Revierte la promoción automática errónea de los seis usuarios demo de 016,
-- retira expedientes activos no elegibles y asegura que solo egresados con noveno
-- semestre concluido y sin inscripciones activas mantengan un proceso MG activo.
SET NAMES utf8mb4 COLLATE utf8mb4_unicode_ci;

-- estudiante1 y estudiante2 tenían semestres iniciales definidos explícitamente en init.sql.
UPDATE estudiantes e JOIN usuarios u ON u.id_usuario=e.id_usuario
SET e.semestre=4,e.estado_academico='activo'
WHERE u.usuario='estudiante1';
UPDATE estudiantes e JOIN usuarios u ON u.id_usuario=e.id_usuario
SET e.semestre=2,e.estado_academico='activo'
WHERE u.usuario='estudiante2';

-- Los estudiantes demo 3..6 fueron creados por init.sql usando la fórmula por id_usuario.
UPDATE estudiantes e JOIN usuarios u ON u.id_usuario=e.id_usuario
SET e.semestre=MOD(e.id_usuario-3,9)+1,e.estado_academico='activo'
WHERE u.usuario IN ('estudiante3','estudiante4','estudiante5','estudiante6');

-- Restituye sus inscripciones ordinarias de demo para reflejar que siguen cursando.
UPDATE inscripciones i JOIN estudiantes e ON e.id_estudiante=i.id_estudiante JOIN usuarios u ON u.id_usuario=e.id_usuario
SET i.estado='activa'
WHERE u.usuario IN ('estudiante1','estudiante2','estudiante3','estudiante4','estudiante5','estudiante6')
  AND i.estado='finalizada';

-- Los procesos no elegibles se conservan como historial, pero dejan de estar activos.
UPDATE expedientes_mg x JOIN estudiantes e ON e.id_estudiante=x.id_estudiante
SET x.estado='retirado',
    x.observaciones=CONCAT(COALESCE(NULLIF(x.observaciones,''),''),CASE WHEN COALESCE(x.observaciones,'')='' THEN '' ELSE '\n' END,
      'Retirado por validación académica: estudiante sin egreso confirmado, sin noveno semestre culminado o con inscripciones activas.')
WHERE x.estado='activo'
  AND (e.semestre<9 OR e.estado_academico NOT IN ('egresado','titulado')
       OR EXISTS (SELECT 1 FROM inscripciones i WHERE i.id_estudiante=e.id_estudiante AND i.estado='activa'));

-- Finaliza asignaciones de tutor vinculadas a expedientes retirados, conservando historial.
UPDATE asignaciones_tutor a JOIN expedientes_mg x ON x.id_expediente=a.id_expediente
SET a.estado='finalizada',a.fecha_fin=COALESCE(a.fecha_fin,CURDATE()),
    a.motivo_fin=COALESCE(a.motivo_fin,'Expediente retirado por validación de requisitos académicos.')
WHERE x.estado='retirado' AND a.estado='vigente';

-- Evita que expedientes duplicados históricos mantengan más de un proceso activo por estudiante.
UPDATE expedientes_mg x
JOIN (SELECT id_estudiante,MIN(id_expediente) AS conservar FROM expedientes_mg WHERE estado='activo' GROUP BY id_estudiante HAVING COUNT(*)>1) d ON d.id_estudiante=x.id_estudiante
SET x.estado='retirado',x.observaciones=CONCAT(COALESCE(NULLIF(x.observaciones,''),''),CASE WHEN COALESCE(x.observaciones,'')='' THEN '' ELSE '\n' END,'Retirado por duplicidad: ya existe otro expediente activo del estudiante.')
WHERE x.estado='activo' AND x.id_expediente<>d.conservar;

-- Los estudiantes con un expediente MG activo no deben conservar solicitudes ordinarias pendientes/confirmadas.
UPDATE tutorias t JOIN estudiantes e ON e.id_estudiante=t.id_estudiante
SET t.estado='cancelada'
WHERE t.estado IN ('pendiente','confirmada')
  AND EXISTS (SELECT 1 FROM expedientes_mg x WHERE x.id_estudiante=e.id_estudiante AND x.estado='activo')
  AND e.semestre>=9 AND e.estado_academico IN ('egresado','titulado')
  AND NOT EXISTS (SELECT 1 FROM inscripciones i WHERE i.id_estudiante=e.id_estudiante AND i.estado='activa');

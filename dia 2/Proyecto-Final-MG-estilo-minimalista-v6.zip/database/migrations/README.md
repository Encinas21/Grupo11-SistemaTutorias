# Migraciones

Los archivos SQL de esta carpeta se ejecutan en orden lexicográfico mediante `scripts/migrar.php`.

Las migraciones históricas que ya están incluidas en `database/00_init_complete.sql` no se vuelven a ejecutar. Las nuevas migraciones del módulo Modalidades de Grado se incorporarán como `009_...sql` a `014_...sql`.

### 013_mg_seguimiento.sql
Reuniones, informes de avance y alertas atendidas.

### 014_mg_bitacora.sql
Asegura la tabla de auditoría MG; la tabla también se crea tempranamente en 009 para soportar auditoría desde P0.


## Regla de elegibilidad de Modalidades de Grado

Las migraciones 016–018 no deben promover estudiantes automáticamente. Para crear o mantener un expediente MG activo, el estudiante debe estar en semestre 9, tener situación académica egresado/titulado y no registrar inscripciones activas. La migración 018 restaura el estado original de los usuarios demo estudiante1..estudiante6 afectados por la versión antigua de 016, y retira como historial los expedientes activos que no cumplen los requisitos.

La migración 019 elimina físicamente expedientes asociados a estudiantes que no cumplen los requisitos de egreso y cancela tutorías ordinarias pendientes/confirmadas de egresados/titulados. La solicitud de tutorías también se bloquea por estado académico, aunque no exista expediente MG activo.

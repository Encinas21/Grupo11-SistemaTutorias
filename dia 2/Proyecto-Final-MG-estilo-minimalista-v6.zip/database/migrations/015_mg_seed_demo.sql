-- HU-019..040 / DEMO-FINAL: datos de demostración MG completos e idempotentes.
-- No representa reglas institucionales adicionales; solo facilita la demo local.
SET NAMES utf8mb4 COLLATE utf8mb4_unicode_ci;

-- Cohortes y catálogos ya existen desde 009; se refuerzan por si la base fue creada sin el seed completo.
INSERT INTO cohortes_mg(codigo,nombre,fecha_inicio,fecha_fin,activa)
SELECT 'G1-2026-03','Grupo 1 - Marzo 2026','2026-03-01',NULL,1
WHERE NOT EXISTS (SELECT 1 FROM cohortes_mg WHERE codigo='G1-2026-03');
INSERT INTO cohortes_mg(codigo,nombre,fecha_inicio,fecha_fin,activa)
SELECT 'G2-2026-09','Grupo 2 - Septiembre 2026','2026-09-01',NULL,1
WHERE NOT EXISTS (SELECT 1 FROM cohortes_mg WHERE codigo='G2-2026-09');

-- No se crean expedientes de demostración automáticamente.
-- Los expedientes solo se registran por administración para estudiantes con egreso validado.

-- Hitos adicionales para que la línea de tiempo muestre ingreso a MG2 y defensa.
INSERT INTO calendario_mg(id_cohorte,etapa,tipo,nombre,orden,fecha_limite,avance_esperado_pct)
SELECT c.id_cohorte,'mg2','ingreso_mg2','Ingreso a MG2',6,DATE_ADD(c.fecha_inicio,INTERVAL 75 DAY),NULL
FROM cohortes_mg c WHERE NOT EXISTS (SELECT 1 FROM calendario_mg k WHERE k.id_cohorte=c.id_cohorte AND k.tipo='ingreso_mg2');
INSERT INTO calendario_mg(id_cohorte,etapa,tipo,nombre,orden,fecha_limite,avance_esperado_pct)
SELECT c.id_cohorte,'mg1','defensa','Defensa MG1 - demo',7,DATE_ADD(CURDATE(),INTERVAL 5 DAY),NULL
FROM cohortes_mg c WHERE NOT EXISTS (SELECT 1 FROM calendario_mg k WHERE k.id_cohorte=c.id_cohorte AND k.tipo='defensa');


-- No se crean etapas ni asignaciones ficticias.

<?php
require_once __DIR__.'/../../includes/seguridad.php';
if (!empty($_SESSION['id_usuario'])) { header('Location:/controllers/dashboard.php'); exit; }
$flash = mostrarFlash();
?><!doctype html>
<html lang="es">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<meta http-equiv="Cache-Control" content="no-store">
<meta http-equiv="Pragma" content="no-cache">
<meta http-equiv="Expires" content="0">
<title>Iniciar sesión | Sistema de Tutorías</title>
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css">
<link rel="stylesheet" href="/assets/css/style.css?v=ui2026">
</head>
<body class="login-page">
<main class="login-shell">
    <section class="login-visual" aria-label="Bienvenida al sistema académico">
        <div class="login-brand"><span class="login-brand-mark"><i class="bi bi-mortarboard-fill" aria-hidden="true"></i></span><span>UPDS <small>Portal académico</small></span></div>
        <div class="login-illustration" aria-hidden="true">
            <div class="illustration-orbit orbit-one"></div><div class="illustration-orbit orbit-two"></div>
            <div class="illustration-window"><span></span><span></span><span></span><i class="bi bi-book-half"></i></div>
            <div class="illustration-desk"></div>
            <div class="illustration-book book-a"></div><div class="illustration-book book-b"></div>
            <div class="illustration-person"><div class="person-head"></div><div class="person-body"></div><div class="person-arm"></div></div>
            <div class="illustration-plant"><span></span><span></span><i></i></div>
        </div>
        <div class="login-visual-copy"><span class="eyebrow">SISTEMA DE APOYO ACADÉMICO</span><h1>Tu camino académico,<br>en un solo lugar.</h1><p>Organiza tus tutorías, consulta tu avance y mantente al día con tu proceso universitario.</p></div>
        <div class="login-visual-footer"><span><i class="bi bi-shield-check"></i> Acceso seguro</span><span>UPDS · Sistema académico</span></div>
    </section>
    <section class="login-panel">
        <div class="login-card">
            <div class="login-mobile-mark"><i class="bi bi-mortarboard-fill"></i></div>
            <div class="login-kicker">BIENVENIDO DE NUEVO</div>
            <h2 class="login-title">Iniciar sesión</h2>
            <p class="login-sub">Ingresa tus datos para continuar.</p>
            <?php if ($flash): ?>
                <div class="alert alert-error" role="alert"><?= e($flash['mensaje']) ?></div>
            <?php endif; ?>
            <form method="post" action="/controllers/login_procesar.php">
                <input type="hidden" name="csrf" value="<?= e(csrf_token()) ?>">
                <div class="form-group">
                    <label class="form-label" for="login">Usuario o correo</label>
                    <div class="login-input-wrap"><i class="bi bi-person" aria-hidden="true"></i><input id="login" required name="login" autocomplete="username" placeholder="Ingresa tu usuario o correo"></div>
                </div>
                <div class="form-group">
                    <label class="form-label" for="clave">Contraseña</label>
                    <div class="login-input-wrap"><i class="bi bi-lock" aria-hidden="true"></i><input id="clave" required type="password" name="clave" autocomplete="current-password" placeholder="Ingresa tu contraseña"></div>
                </div>
                <button class="btn btn-primary login-submit" type="submit">Ingresar <i class="bi bi-arrow-right" aria-hidden="true"></i></button>
            </form>
            <p class="login-help"><i class="bi bi-info-circle" aria-hidden="true"></i> Si tienes problemas para acceder, contacta al administrador del sistema.</p>
        </div>
        <div class="login-panel-footer">© <?= date('Y') ?> Sistema Web de Apoyo Académico para Tutorías</div>
    </section>
</main>
<script src="/assets/js/app.js?v=ui2026"></script>
</body>
</html>

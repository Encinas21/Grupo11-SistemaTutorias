-- Corrige los usuarios de demostración que la migración 016 pudo marcar como egresados
-- aunque aún cursan semestres inferiores al último. Conserva el expediente como
-- registro histórico, pero lo retira para que no siga apareciendo como proceso activo.
SET NAMES utf8mb4 COLLATE utf8mb4_unicode_ci;

UPDATE estudiantes e
JOIN usuarios u ON u.id_usuario=e.id_usuario
SET e.estado_academico='activo'
WHERE u.usuario IN ('estudiante1','estudiante2','estudiante3','estudiante4','estudiante5','estudiante6')
  AND e.semestre < 9;

UPDATE expedientes_mg x
JOIN estudiantes e ON e.id_estudiante=x.id_estudiante
JOIN usuarios u ON u.id_usuario=e.id_usuario
SET x.estado='retirado',
    x.observaciones=CONCAT(COALESCE(NULLIF(x.observaciones,''),''),
      CASE WHEN COALESCE(x.observaciones,'')='' THEN '' ELSE '\n' END,
      'Retirado por corrección de datos: el estudiante no figura como egresado/titulado.')
WHERE x.estado='activo'
  AND (e.estado_academico NOT IN ('egresado','titulado')
       OR e.semestre < 9
       OR EXISTS (SELECT 1 FROM inscripciones i WHERE i.id_estudiante=e.id_estudiante AND i.estado='activa'));

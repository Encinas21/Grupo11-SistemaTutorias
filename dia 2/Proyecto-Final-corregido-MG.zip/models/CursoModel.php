<?php class CursoModel {private PDO $pdo;function __construct(PDO $pdo){$this->pdo=$pdo;} function obtenerTodas(){return $this->pdo->query("SELECT c.*,ca.nombre_carrera,CONCAT(u.nombre,' ',u.apellido) docente,COUNT(i.id_inscripcion) total_inscritos FROM cursos c LEFT JOIN carreras ca ON ca.id_carrera=c.id_carrera LEFT JOIN profesores p ON p.id_profesor=c.id_profesor LEFT JOIN usuarios u ON u.id_usuario=p.id_usuario LEFT JOIN inscripciones i ON i.id_curso=c.id_curso GROUP BY c.id_curso ORDER BY c.codigo")->fetchAll();} function obtenerPorId($id){$s=$this->pdo->prepare('SELECT * FROM cursos WHERE id_curso=?');$s->execute([$id]);return $s->fetch();} function crear($d){$s=$this->pdo->prepare('INSERT INTO cursos(nombre_curso,codigo,id_carrera,id_profesor,semestre,descripcion,estado) VALUES(?,?,?,?,?,?,?)');return $s->execute([$d['nombre_curso'],$d['codigo'],$d['id_carrera']?:null,$d['id_profesor']?:null,$d['semestre']?:null,$d['descripcion'] ?? '',$d['estado'] ?? 'activo']);} function editar($id,$d){$s=$this->pdo->prepare('UPDATE cursos SET nombre_curso=?,codigo=?,id_carrera=?,id_profesor=?,semestre=?,descripcion=?,estado=? WHERE id_curso=?');return $s->execute([$d['nombre_curso'],$d['codigo'],$d['id_carrera']?:null,$d['id_profesor']?:null,$d['semestre']?:null,$d['descripcion'] ?? '',$d['estado'] ?? 'activo',$id]);} function eliminar($id){$s=$this->pdo->prepare('DELETE FROM cursos WHERE id_curso=?');return $s->execute([$id]);}

    /**
     * Cursos a cargo de un profesor, con sus materias asociadas, para que
     * pueda elegir "curso y materia" al tomar asistencia o ver su listado.
     */
    function obtenerPorProfesor(int $idUsuarioProfesor): array
    {
        $sql = "
            SELECT
                c.id_curso,
                c.nombre_curso,
                c.codigo,
                GROUP_CONCAT(DISTINCT m.nombre_materia ORDER BY m.nombre_materia SEPARATOR ', ') AS materias
            FROM cursos c
            JOIN profesores p ON p.id_profesor = c.id_profesor
            LEFT JOIN materias m ON m.id_curso = c.id_curso
            WHERE p.id_usuario = ?
            GROUP BY c.id_curso
            ORDER BY c.codigo
        ";
        $stmt = $this->pdo->prepare($sql);
        $stmt->execute([$idUsuarioProfesor]);

        return $stmt->fetchAll();
    }
}
